package code;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String inp="";
		int amt = 0;
		int left=0;
		int right=0;
		boolean again = false;
		boolean goodInp = false;
		
		char[] cowArray = {}; 

		do
		{
			System.out.println("forward or backwards?(1/2)(f/b)");
			inp = input.next();
			//forwards
			if(inp.equals("1") || inp.equals("f"))
			{
				System.out.println("String of h and s:");
				inp = input.next();
				cowArray = inp.toCharArray();
				System.out.println("how many generations?");
				amt = input.nextInt();		
				
				for(int y = 0; y<amt; y++)
				{
					for(int x = 0; x<cowArray.length; x++)
					{
						if(x>0)
							left = x-1;
						if(x<cowArray.length-1)
							right = x+1;
						if(cowArray[x]=='h' && (cowArray[left]=='s' || cowArray[right]=='s'))
							cowArray[x]='a';
						
					}
					for(int x = 0; x<cowArray.length; x++)
					{
						if(cowArray[x]=='a')
						{
							cowArray[x]='s';
						}
					}
					System.out.println("Day " + (y+1));
					System.out.println(cowArray);
				}
				
			}
			//backwards
			if(inp.equals("2") || inp.equals("b"))
			{
				System.out.println("String of h and s:");
				inp = input.next();
				cowArray = inp.toCharArray();
				System.out.println("how many generations?");
				amt = input.nextInt();		
				
				for(int y = 0; y<amt; y++)
				{
					for(int x = 0; x<cowArray.length; x++)
					{
						if(x>0)
							left = x-1;
						if(x<cowArray.length-1)
							right = x+1;
						if(cowArray[x]=='s' && (cowArray[left]=='h' && cowArray[right]=='s') || (cowArray[left]=='s' && cowArray[right]=='h'))
							cowArray[x]='a';
						
					}
					for(int x = 0; x<cowArray.length; x++)
					{
						if(cowArray[x]=='a')
						{
							cowArray[x]='h';
						}
					}
					System.out.println("Day " + (y+1));
					System.out.println(cowArray);
				}
				
			}
			do
			{
				System.out.println("New simulation? (y/n)");
				inp = input.next();
				if(inp.equals("yes")||inp.equals("y"))
				{
					again=true;
					goodInp=true;
					System.out.println("New simulation...");
				}
				else if(inp.equals("no") || inp.equals("n"))
				{
					again=false;
					goodInp=true;
					System.out.println("Exitting...");
				}
			}while(!goodInp);
		}while(again);
		System.out.println("bye");
	}

}
