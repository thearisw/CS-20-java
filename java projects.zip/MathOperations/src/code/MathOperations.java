package code;
import java.util.Scanner;

public class MathOperations {
	public static int add(int n1, int n2)
	{
		int total = n1+n2;
		return total;
	}
	public static int subtract(int n1, int n2)
	{
		int total = n1-n2;
		return total;
	}
	public static int multiply(int n1, int n2)
	{
		int total = n1*n2;
		return total;
	}
	public static int divide(int n1, int n2)
	{
		int total = n1/n2;
		return total;
	}
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String inp="";
		String a ="add";
		String s ="subtract";
		String m ="multiply";
		String d ="divide";
		
		int n1=0;
		int n2=0;
		boolean invalid=true;
		
		do
		{
			System.out.println("Select (add) (subtract) (multiply) (divide)");
			inp = input.next();
			if(inp.equals(a) || inp.equals(s) || inp.equals(m) || inp.equals(d))
			{
				invalid=false;
			}
		}while(invalid);
		if(inp.equals(a))
		{
			System.out.println("Insert first number");
			try
			{
				n1=input.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("Invalid input. Default set to 0.");
			}
			System.out.println("Insert second number");
			try
			{
				n2=input.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("Invalid input. Default set to 0.");
			}
			System.out.println(add(n1,n2));
		}
		if(inp.equals(s))
		{
			System.out.println("Insert first number");
			try
			{
				n1=input.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("Invalid input. Default set to 0.");
			}
			System.out.println("Insert second number");
			try
			{
				n2=input.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("Invalid input. Default set to 0.");
			}
			System.out.println(subtract(n1,n2));
		}
		if(inp.equals(m))
		{
			System.out.println("Insert first number");
			try
			{
				n1=input.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("Invalid input. Default set to 0.");
			}
			System.out.println("Insert second number");
			try
			{
				n2=input.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("Invalid input. Default set to 0.");
			}
			System.out.println(multiply(n1,n2));
		}
		if(inp.equals(d))
		{
			System.out.println("Insert first number");
			try
			{
				n1=input.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("Invalid input. Default set to 0.");
			}
			System.out.println("Insert second number");
			try
			{
				n2=input.nextInt();
			}
			catch(Exception e)
			{
				System.out.println("Invalid input. Default set to 0.");
			}
			System.out.println(divide(n1,n2));
		}
	}

}
